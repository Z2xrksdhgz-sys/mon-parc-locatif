import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Politique de confidentialité & RGPD — Mon Parc Locatif',
}

export default function PolitiqueConfidentialitePage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
      <h1 className="text-4xl font-bold text-gray-900 mb-2">Politique de confidentialité & RGPD</h1>
      <p className="text-sm text-gray-500 mb-10">Dernière mise à jour : juin 2025</p>

      <div className="space-y-10 text-sm leading-relaxed text-gray-700">

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">1. Identité du responsable de traitement</h2>
          <div className="bg-gray-50 rounded-xl p-5 space-y-1.5">
            <p><span className="font-medium text-gray-800">Responsable :</span> Rémi DUMAS</p>
            <p><span className="font-medium text-gray-800">Statut :</span> Auto-entrepreneur — SIRET 939 443 776 00017</p>
            <p><span className="font-medium text-gray-800">Adresse :</span> 5 rue Lobineau, 75006 Paris</p>
            <p><span className="font-medium text-gray-800">Contact :</span> <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-600 hover:underline">contact@moncontratdelocation.fr</a></p>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">2. Données collectées</h2>
          <p>Dans le cadre de l&apos;utilisation de la plateforme Mon Parc Locatif, nous collectons les données suivantes :</p>
          <div className="mt-4 space-y-4">
            {[
              {
                title: 'Données d\'identification',
                items: ['Nom, prénom', 'Adresse email', 'Mot de passe (chiffré — jamais stocké en clair)'],
              },
              {
                title: 'Données de gestion locative',
                items: ['Informations sur les biens (adresse, type, surface, loyer…)', 'Informations sur les locataires (identité, coordonnées)', 'Informations financières (loyers, charges, quittances)', 'Documents associés (baux, états des lieux, diagnostics…)'],
              },
              {
                title: 'Données de paiement',
                items: ['Traitement via Stripe — nous ne stockons aucune donnée bancaire', 'Historique des transactions (référence, montant, date)'],
              },
              {
                title: 'Données techniques',
                items: ['Adresse IP', 'Données de navigation (pages visitées, durée de session)', 'Type de navigateur et système d\'exploitation'],
              },
            ].map(({ title, items }) => (
              <div key={title} className="bg-white border border-gray-200 rounded-xl p-5">
                <p className="font-semibold text-gray-900 mb-2">{title}</p>
                <ul className="space-y-1">
                  {items.map(i => <li key={i} className="flex items-start gap-2"><span className="text-orange-500 flex-shrink-0">•</span>{i}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">3. Finalités et bases légales du traitement</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left p-3 border border-gray-200 font-semibold text-gray-800">Finalité</th>
                  <th className="text-left p-3 border border-gray-200 font-semibold text-gray-800">Base légale</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Fourniture du service de gestion locative', 'Exécution du contrat (art. 6.1.b RGPD)'],
                  ['Gestion de l\'abonnement et facturation', 'Exécution du contrat (art. 6.1.b RGPD)'],
                  ['Amélioration du service et de l\'expérience utilisateur', 'Intérêt légitime (art. 6.1.f RGPD)'],
                  ['Envoi de communications transactionnelles', 'Exécution du contrat (art. 6.1.b RGPD)'],
                  ['Envoi de communications marketing (avec consentement)', 'Consentement (art. 6.1.a RGPD)'],
                  ['Respect des obligations légales', 'Obligation légale (art. 6.1.c RGPD)'],
                  ['Prévention de la fraude et sécurité', 'Intérêt légitime (art. 6.1.f RGPD)'],
                ].map(([finalite, base], i) => (
                  <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="p-3 border border-gray-200">{finalite}</td>
                    <td className="p-3 border border-gray-200 text-gray-500">{base}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">4. Durée de conservation</h2>
          <div className="space-y-3">
            {[
              { type: 'Données de compte actif', duree: 'Durée de l\'abonnement + 30 jours après résiliation' },
              { type: 'Documents générés (baux, quittances…)', duree: 'Durée de l\'abonnement + 30 jours après résiliation' },
              { type: 'Données de facturation', duree: '10 ans (obligation légale comptable)' },
              { type: 'Données de navigation', duree: '13 mois maximum' },
              { type: 'Données relatives aux locataires', duree: 'Durée de la relation locative + 3 ans' },
            ].map(({ type, duree }) => (
              <div key={type} className="flex flex-col sm:flex-row gap-1 sm:gap-4 py-2 border-b border-gray-100 last:border-0">
                <span className="font-medium text-gray-800 sm:w-72 flex-shrink-0">{type}</span>
                <span className="text-gray-600">{duree}</span>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">5. Partage et destinataires des données</h2>
          <p className="mb-4">Nous ne vendons jamais vos données personnelles à des tiers. Vos données peuvent être partagées uniquement avec :</p>
          <div className="space-y-3">
            {[
              { dest: 'Stripe', role: 'Prestataire de paiement — traitement sécurisé des transactions', pays: 'États-Unis (garanties RGPD)' },
              { dest: 'Vercel', role: 'Hébergeur de la plateforme', pays: 'États-Unis (garanties RGPD)' },
              { dest: 'Firebase (Google)', role: 'Base de données — stockage sécurisé des données', pays: 'Union Européenne' },
              { dest: 'Resend', role: 'Service d\'envoi d\'emails transactionnels', pays: 'Union Européenne' },
            ].map(({ dest, role, pays }) => (
              <div key={dest} className="bg-white border border-gray-200 rounded-xl p-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-gray-900">{dest}</span>
                  <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{pays}</span>
                </div>
                <p className="text-xs text-gray-500">{role}</p>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">6. Vos droits</h2>
          <p className="mb-4">Conformément au RGPD, vous disposez des droits suivants sur vos données personnelles :</p>
          <div className="grid sm:grid-cols-2 gap-3">
            {[
              { droit: '🔍 Droit d\'accès', desc: 'Obtenir une copie de toutes vos données' },
              { droit: '✏️ Droit de rectification', desc: 'Corriger des données inexactes' },
              { droit: '🗑️ Droit à l\'effacement', desc: 'Demander la suppression de vos données' },
              { droit: '⏸️ Droit de limitation', desc: 'Limiter certains traitements de vos données' },
              { droit: '📦 Droit à la portabilité', desc: 'Recevoir vos données dans un format lisible' },
              { droit: '🚫 Droit d\'opposition', desc: 'Vous opposer à certains traitements' },
            ].map(({ droit, desc }) => (
              <div key={droit} className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                <p className="font-semibold text-gray-900 text-sm mb-1">{droit}</p>
                <p className="text-xs text-gray-500">{desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-5 bg-orange-50 border border-orange-200 rounded-xl p-5">
            <p className="font-semibold text-gray-900 mb-2">Exercer vos droits</p>
            <p>Pour exercer l&apos;un de ces droits, contactez-nous à :<br />
              <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-600 hover:underline font-medium">contact@moncontratdelocation.fr</a>
            </p>
            <p className="mt-2 text-gray-500 text-xs">Nous répondrons dans un délai maximum de 30 jours. Vous pouvez également introduire une réclamation auprès de la <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-orange-600 hover:underline">CNIL</a>.</p>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">7. Sécurité des données</h2>
          <p>Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger vos données :</p>
          <ul className="mt-3 space-y-2">
            {[
              'Chiffrement des données en transit (HTTPS/TLS)',
              'Chiffrement des données au repos (AES-256)',
              'Mots de passe hachés et salés (jamais stockés en clair)',
              'Accès aux données restreint aux seuls agents autorisés',
              'Sauvegardes régulières et sécurisées',
              'Surveillance et alertes en cas d\'activité suspecte',
            ].map(m => (
              <li key={m} className="flex items-start gap-2 text-sm">
                <span className="text-orange-500 flex-shrink-0 mt-0.5">✓</span>
                {m}
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">8. Cookies</h2>
          <p>Le site utilise uniquement des cookies techniques strictement nécessaires au fonctionnement du service :</p>
          <ul className="mt-3 space-y-2">
            {[
              { nom: 'Cookie de session', desc: 'Maintient votre connexion entre les pages — durée : session' },
              { nom: 'Cookie de préférences', desc: 'Mémorise vos paramètres d\'affichage — durée : 1 an' },
            ].map(({ nom, desc }) => (
              <li key={nom} className="flex items-start gap-2 text-sm">
                <span className="text-orange-500 flex-shrink-0 mt-0.5">•</span>
                <span><span className="font-medium text-gray-800">{nom} :</span> {desc}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-gray-500">Ces cookies ne nécessitent pas de consentement préalable car ils sont indispensables au service.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">9. Modifications</h2>
          <p>Nous nous réservons le droit de modifier cette politique de confidentialité à tout moment. Les utilisateurs seront informés par email de toute modification substantielle. La version en vigueur est toujours accessible sur cette page.</p>
        </section>

        <div className="bg-gray-900 rounded-2xl p-6 text-center">
          <p className="text-white font-semibold mb-2">Une question sur vos données ?</p>
          <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-400 hover:text-orange-300 text-sm font-medium">
            contact@moncontratdelocation.fr
          </a>
        </div>
      </div>
    </div>
  )
}
