import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Tarifs — Mon Parc Locatif',
  description: 'Découvrez nos 3 offres de gestion locative : START à 6,90€/mois, EXPERT à 15,80€/mois et RENTIER à 47,80€/mois. Sans engagement.',
}

function Check({ muted = false }: { muted?: boolean }) {
  return (
    <svg className={`w-4 h-4 flex-shrink-0 mt-0.5 ${muted ? 'text-gray-300' : 'text-orange-500'}`} viewBox="0 0 16 16" fill="none">
      <path d="M3 8l4 4 6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
}

const plans = [
  {
    id: 'start',
    name: 'START',
    desc: 'Pour démarrer avec un premier bien',
    price: 6.90,
    priceAnnual: 5.86,
    discountAnnual: 15,
    locations: '1 location',
    color: 'gray',
    featured: false,
    features: [
      'Pilotage locatif complet',
      'Génération des documents légaux',
      'Comptabilité & Finance',
      'Espace locataire',
      'Stockage documents',
    ],
    extras: [
      { label: 'Signature électronique', note: '2-3 € / signature (paiement à l\'unité)' },
    ],
  },
  {
    id: 'expert',
    name: 'EXPERT',
    desc: 'Pour les bailleurs avec plusieurs biens',
    price: 15.80,
    priceAnnual: 12.64,
    discountAnnual: 20,
    locations: 'Jusqu\'à 10 locations',
    color: 'orange',
    featured: true,
    features: [
      'Pilotage locatif complet',
      'Génération documents légaux illimités',
      'Comptabilité & Finance',
      'Espace locataire',
      'Stockage documents',
      'Signatures électroniques incluses',
      'Multi-profils bailleurs (SCI, LMNP…)',
      'Support téléphonique',
      'Gestion des sinistres',
      'Rapports avancés',
      'Dossier de demande de crédit automatique',
      'Accès à la communauté',
    ],
    extras: [],
  },
  {
    id: 'rentier',
    name: 'RENTIER',
    desc: 'Pour les patrimoines importants',
    price: 47.80,
    priceAnnual: 33.46,
    discountAnnual: 30,
    locations: 'Jusqu\'à 50 locations',
    color: 'dark',
    featured: false,
    features: [
      'Pilotage locatif complet',
      'Génération documents légaux illimités',
      'Comptabilité & Finance',
      'Espace locataire',
      'Stockage documents',
      'Signatures électroniques incluses',
      'Multi-profils bailleurs (SCI, LMNP…)',
      'Support téléphonique prioritaire',
      'Gestion des sinistres',
      'Rapports avancés',
      'Dossier de demande de crédit automatique',
      'Accès à la communauté',
    ],
    extras: [],
  },
]

const faq = [
  { q: 'Puis-je changer d\'offre en cours d\'abonnement ?', r: 'Oui, vous pouvez upgrader ou downgrader votre offre à tout moment. Le changement est effectif immédiatement et le montant est ajusté au prorata.' },
  { q: 'Y a-t-il un engagement de durée ?', r: 'Non. Toutes nos offres sont sans engagement. Vous pouvez résilier à tout moment depuis votre espace, avec effet à la fin de la période en cours.' },
  { q: 'Comment fonctionne la réduction annuelle ?', r: 'En optant pour le paiement annuel, vous bénéficiez d\'une réduction immédiate (15%, 20% ou 30% selon l\'offre). Le montant annuel est prélevé en une seule fois.' },
  { q: 'La signature électronique est-elle légalement valable ?', r: 'Oui. Les signatures électroniques intégrées à Mon Parc Locatif sont conformes au règlement européen eIDAS et ont la même valeur juridique qu\'une signature manuscrite.' },
  { q: 'Mes données sont-elles sécurisées ?', r: 'Toutes vos données sont stockées sur des serveurs sécurisés (chiffrement AES-256), hébergés en Europe. Nous ne vendons jamais vos données.' },
  { q: 'Que se passe-t-il au-delà de 50 biens ?', r: 'Pour les patrimoines de plus de 50 biens, nous proposons une offre sur mesure adaptée à vos besoins. Contactez-nous via le formulaire de contact.' },
]

export default function TarifsPage() {
  return (
    <div className="antialiased">

      {/* Header */}
      <section className="bg-gradient-to-b from-orange-50 to-white py-16 px-4 sm:px-6 text-center">
        <div className="max-w-3xl mx-auto">
          <p className="text-sm font-semibold text-orange-600 uppercase tracking-wider mb-3">Tarifs</p>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">Simple et transparent.</h1>
          <p className="text-xl text-gray-500 font-normal leading-relaxed">
            3 offres adaptées à votre parc. Sans engagement, résiliable à tout moment.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="py-16 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">

          {/* Toggle mensuel/annuel (visuel uniquement) */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className="text-sm text-gray-400">Mensuel</span>
            <div className="relative w-12 h-6 bg-orange-600 rounded-full cursor-pointer">
              <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
            </div>
            <span className="text-sm font-semibold text-gray-900">
              Annuel <span className="text-orange-600 text-xs font-bold">— jusqu&apos;à -30%</span>
            </span>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div key={plan.id}
                className={`rounded-2xl p-8 flex flex-col relative border-2 ${
                  plan.featured
                    ? 'border-orange-500 bg-white shadow-xl shadow-orange-100'
                    : plan.color === 'dark'
                    ? 'border-gray-200 bg-gray-900'
                    : 'border-gray-200 bg-white'
                }`}
              >
                {plan.featured && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-orange-600 text-white text-xs font-bold px-5 py-1.5 rounded-full whitespace-nowrap">
                    Le plus populaire
                  </div>
                )}

                <div className={`text-xs font-bold uppercase tracking-widest mb-2 ${
                  plan.featured ? 'text-orange-600' : plan.color === 'dark' ? 'text-orange-400' : 'text-gray-400'
                }`}>
                  {plan.name}
                </div>

                <p className={`text-sm mb-6 ${plan.color === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                  {plan.desc}
                </p>

                {/* Prix mensuel */}
                <div className="mb-1">
                  <div className="flex items-baseline gap-1">
                    <span className={`text-5xl font-bold ${plan.color === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                      {plan.price.toFixed(2).replace('.', ',')}
                    </span>
                    <span className={`text-lg ${plan.color === 'dark' ? 'text-gray-400' : 'text-gray-400'}`}>€</span>
                    <span className={`text-sm ${plan.color === 'dark' ? 'text-gray-400' : 'text-gray-400'}`}>/mois</span>
                  </div>
                  <p className={`text-sm mt-1 ${plan.color === 'dark' ? 'text-gray-400' : 'text-gray-400'}`}>
                    ou <strong className={plan.color === 'dark' ? 'text-white' : 'text-gray-700'}>{plan.priceAnnual.toFixed(2).replace('.', ',')} €/mois</strong> en annuel (-{plan.discountAnnual}%)
                  </p>
                </div>

                <div className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full mb-6 w-fit ${
                  plan.featured ? 'bg-orange-50 text-orange-700' : plan.color === 'dark' ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'
                }`}>
                  <svg width="11" height="11" viewBox="0 0 14 14" fill="none"><path d="M2 8.5V6L7 1.5 12 6v2.5M2 8.5v4h3.5V10h3v2.5H12V8.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  {plan.locations}
                </div>

                <div className={`border-t mb-6 ${plan.color === 'dark' ? 'border-gray-800' : 'border-gray-100'}`} />

                <ul className="space-y-3 flex-1 mb-6">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm">
                      <Check />
                      <span className={plan.color === 'dark' ? 'text-gray-300' : 'text-gray-600'}>{f}</span>
                    </li>
                  ))}
                </ul>

                {plan.extras.length > 0 && (
                  <div className={`rounded-lg p-3 mb-6 ${plan.color === 'dark' ? 'bg-gray-800' : 'bg-gray-50'}`}>
                    <p className={`text-xs font-semibold mb-2 ${plan.color === 'dark' ? 'text-gray-400' : 'text-gray-500'} uppercase tracking-wider`}>
                      Options payantes
                    </p>
                    {plan.extras.map((e) => (
                      <div key={e.label} className="flex items-start gap-2 text-xs">
                        <span className="text-orange-400 flex-shrink-0 mt-0.5">+</span>
                        <span className={plan.color === 'dark' ? 'text-gray-400' : 'text-gray-500'}>
                          <span className="font-medium">{e.label}</span> — {e.note}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                <Link
                  href={`/inscription?plan=${plan.id}`}
                  className={`block text-center font-semibold py-3.5 rounded-xl transition-colors text-sm ${
                    plan.featured
                      ? 'bg-orange-600 hover:bg-orange-700 text-white'
                      : plan.color === 'dark'
                      ? 'bg-white hover:bg-gray-100 text-gray-900'
                      : 'bg-gray-900 hover:bg-gray-800 text-white'
                  }`}
                >
                  Démarrer avec {plan.name}
                </Link>
              </div>
            ))}
          </div>

          {/* Sur mesure */}
          <div className="mt-8 bg-orange-50 border border-orange-200 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <p className="text-xs font-semibold text-orange-600 uppercase tracking-wider mb-2">Sur mesure</p>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Plus de 50 biens ?</h3>
              <p className="text-gray-600 text-sm leading-relaxed max-w-lg">
                Pour les grands patrimoines et les professionnels de l&apos;immobilier, nous proposons une offre sur mesure avec tarification adaptée, onboarding dédié et support prioritaire.
              </p>
            </div>
            <Link href="/contact?sujet=sur-mesure"
              className="flex-shrink-0 bg-orange-600 hover:bg-orange-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors text-sm whitespace-nowrap">
              Nous contacter →
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6 bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <p className="text-sm font-semibold text-orange-600 uppercase tracking-wider mb-3 text-center">FAQ</p>
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Questions fréquentes</h2>
          <div className="space-y-4">
            {faq.map(({ q, r }) => (
              <div key={q} className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-2">{q}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{r}</p>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-gray-500 mt-10">
            Une autre question ?{' '}
            <Link href="/contact" className="text-orange-600 hover:text-orange-700 font-semibold">
              Contactez-nous
            </Link>
          </p>
        </div>
      </section>
    </div>
  )
}
