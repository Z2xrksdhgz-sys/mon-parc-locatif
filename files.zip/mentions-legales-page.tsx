import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Mentions légales — Mon Parc Locatif',
}

export default function MentionsLegalesPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
      <h1 className="text-4xl font-bold text-gray-900 mb-2">Mentions légales</h1>
      <p className="text-sm text-gray-500 mb-10">Conformément à la loi n°2004-575 du 21 juin 2004 pour la confiance dans l&apos;économie numérique</p>

      <div className="space-y-10 text-sm leading-relaxed text-gray-700">

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Éditeur du site</h2>
          <div className="bg-gray-50 rounded-xl p-6 space-y-2">
            <p><span className="font-semibold text-gray-800">Nom :</span> Rémi DUMAS</p>
            <p><span className="font-semibold text-gray-800">Statut :</span> Auto-entrepreneur</p>
            <p><span className="font-semibold text-gray-800">SIRET :</span> 939 443 776 00017</p>
            <p><span className="font-semibold text-gray-800">Siège social :</span> 5 rue Lobineau, 75006 Paris, France</p>
            <p><span className="font-semibold text-gray-800">Email :</span> <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-600 hover:underline">contact@moncontratdelocation.fr</a></p>
            <p><span className="font-semibold text-gray-800">Directeur de la publication :</span> Rémi DUMAS</p>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Hébergeur</h2>
          <div className="bg-gray-50 rounded-xl p-6 space-y-2">
            <p><span className="font-semibold text-gray-800">Société :</span> Vercel Inc.</p>
            <p><span className="font-semibold text-gray-800">Adresse :</span> 340 Pine Street, Suite 701, San Francisco, CA 94104, États-Unis</p>
            <p><span className="font-semibold text-gray-800">Site web :</span> <a href="https://vercel.com" target="_blank" rel="noopener noreferrer" className="text-orange-600 hover:underline">vercel.com</a></p>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Propriété intellectuelle</h2>
          <p>L&apos;ensemble du contenu du site mon-parc-locatif.fr (textes, images, graphismes, logo, icônes, sons, logiciels, etc.) est la propriété exclusive de Rémi DUMAS, à l&apos;exception des contenus provenant de partenaires ou de tiers clairement identifiés.</p>
          <p className="mt-3">Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable de Rémi DUMAS.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Données personnelles</h2>
          <p>Le traitement des données personnelles collectées sur le site est décrit dans notre <a href="/politique-de-confidentialite" className="text-orange-600 hover:underline font-medium">Politique de Confidentialité & RGPD</a>.</p>
          <p className="mt-3">Conformément à la loi Informatique et Libertés du 6 janvier 1978 modifiée et au Règlement Général sur la Protection des Données (RGPD), vous disposez d&apos;un droit d&apos;accès, de rectification, de suppression et de portabilité de vos données personnelles. Pour exercer ces droits, contactez-nous à : <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-600 hover:underline">contact@moncontratdelocation.fr</a></p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Cookies</h2>
          <p>Le site mon-parc-locatif.fr utilise des cookies techniques nécessaires au bon fonctionnement du service (session utilisateur, préférences). Ces cookies ne collectent pas de données personnelles à des fins publicitaires.</p>
          <p className="mt-3">En continuant à utiliser le site, vous acceptez l&apos;utilisation de ces cookies techniques. Pour en savoir plus, consultez notre <a href="/politique-de-confidentialite" className="text-orange-600 hover:underline">Politique de Confidentialité</a>.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Limitation de responsabilité</h2>
          <p>Rémi DUMAS ne pourra être tenu responsable des dommages directs et indirects causés au matériel de l&apos;utilisateur lors de l&apos;accès au site mon-parc-locatif.fr, résultant de l&apos;utilisation d&apos;un matériel ne répondant pas aux spécifications techniques requises.</p>
          <p className="mt-3">Rémi DUMAS ne saurait également être tenu responsable des dommages indirects consécutifs à l&apos;utilisation du site.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Liens hypertextes</h2>
          <p>Le site mon-parc-locatif.fr peut contenir des liens vers d&apos;autres sites internet. Rémi DUMAS n&apos;exerce aucun contrôle sur ces sites et décline toute responsabilité quant à leur contenu.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Droit applicable</h2>
          <p>Tout litige en relation avec l&apos;utilisation du site mon-parc-locatif.fr est soumis au droit français. Il est fait attribution exclusive de juridiction aux tribunaux compétents de Paris.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Contact</h2>
          <p>Pour toute question ou réclamation relative au site : <a href="mailto:contact@moncontratdelocation.fr" className="text-orange-600 hover:underline font-medium">contact@moncontratdelocation.fr</a></p>
        </section>
      </div>
    </div>
  )
}
