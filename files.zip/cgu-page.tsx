import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Conditions Générales d\'Utilisation — Mon Parc Locatif',
}

export default function CguPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
      <h1 className="text-4xl font-bold text-gray-900 mb-2">Conditions Générales d&apos;Utilisation</h1>
      <p className="text-sm text-gray-500 mb-10">Dernière mise à jour : juin 2025</p>

      <div className="prose prose-gray max-w-none space-y-10 text-sm leading-relaxed text-gray-700">

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 1 — Objet et champ d&apos;application</h2>
          <p>Les présentes Conditions Générales d&apos;Utilisation (ci-après « CGU ») ont pour objet de définir les modalités et conditions d&apos;utilisation de la plateforme <strong>Mon Parc Locatif</strong>, accessible à l&apos;adresse <strong>mon-parc-locatif.fr</strong>, éditée par Rémi DUMAS, auto-entrepreneur (SIRET 939 443 776 00017), dont le siège social est situé au 5 rue Lobineau, 75006 Paris.</p>
          <p className="mt-3">L&apos;utilisation de la plateforme implique l&apos;acceptation pleine et entière des présentes CGU. Toute personne qui accède et utilise la plateforme est réputée avoir pris connaissance et accepté les présentes conditions.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 2 — Description du service</h2>
          <p>Mon Parc Locatif est une plateforme SaaS (Software as a Service) de gestion locative destinée aux bailleurs particuliers et professionnels. Elle permet notamment :</p>
          <ul className="list-disc pl-6 mt-3 space-y-1.5">
            <li>La gestion de biens immobiliers locatifs (appartements, maisons, parkings, etc.)</li>
            <li>Le suivi des loyers, la génération de quittances et d&apos;avis d&apos;échéance</li>
            <li>La gestion des profils locataires et des dossiers de candidature</li>
            <li>La génération de documents légaux (baux, états des lieux, inventaires)</li>
            <li>La signature électronique de documents</li>
            <li>Le suivi comptable et financier par bien et par profil bailleur</li>
            <li>La gestion des incidents et des assurances</li>
            <li>La messagerie bailleur-locataire et le coffre-fort documentaire</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 3 — Accès au service et création de compte</h2>
          <p>L&apos;accès à la plateforme nécessite la création d&apos;un compte utilisateur. L&apos;utilisateur s&apos;engage à fournir des informations exactes, complètes et à jour lors de son inscription, et à mettre à jour ces informations en cas de changement.</p>
          <p className="mt-3">L&apos;utilisateur est responsable de la confidentialité de ses identifiants de connexion et de toutes les actions effectuées depuis son compte. Toute utilisation non autorisée du compte doit être signalée immédiatement à l&apos;éditeur.</p>
          <p className="mt-3">L&apos;éditeur se réserve le droit de suspendre ou de supprimer tout compte en cas de non-respect des présentes CGU.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 4 — Abonnements et tarification</h2>
          <p>L&apos;accès aux fonctionnalités de la plateforme est soumis à la souscription d&apos;un abonnement payant selon les offres proposées :</p>
          <ul className="list-disc pl-6 mt-3 space-y-1.5">
            <li><strong>START</strong> : 6,90 € HT/mois (ou 5,86 € HT/mois en cas de paiement annuel) — jusqu&apos;à 1 location</li>
            <li><strong>EXPERT</strong> : 15,80 € HT/mois (ou 12,64 € HT/mois en cas de paiement annuel) — jusqu&apos;à 10 locations</li>
            <li><strong>RENTIER</strong> : 47,80 € HT/mois (ou 33,46 € HT/mois en cas de paiement annuel) — jusqu&apos;à 50 locations</li>
            <li><strong>Sur mesure</strong> : tarification personnalisée pour les parcs de plus de 50 locations</li>
          </ul>
          <p className="mt-3">Les abonnements sont sans engagement de durée minimum. L&apos;utilisateur peut résilier à tout moment, avec effet à la fin de la période d&apos;abonnement en cours. Les paiements effectués ne sont pas remboursables.</p>
          <p className="mt-3">L&apos;éditeur se réserve le droit de modifier les tarifs, avec notification préalable de 30 jours à l&apos;utilisateur.</p>
          <p className="mt-3">Les paiements sont traités de manière sécurisée par <strong>Stripe</strong>. L&apos;éditeur ne conserve aucune donnée bancaire.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 5 — Obligations de l&apos;utilisateur</h2>
          <p>L&apos;utilisateur s&apos;engage à :</p>
          <ul className="list-disc pl-6 mt-3 space-y-1.5">
            <li>Utiliser la plateforme conformément à sa destination et aux lois en vigueur</li>
            <li>Ne pas utiliser la plateforme à des fins illicites ou frauduleuses</li>
            <li>Ne pas tenter de porter atteinte à la sécurité de la plateforme</li>
            <li>Ne pas utiliser la plateforme pour collecter des données personnelles de tiers sans leur consentement</li>
            <li>S&apos;assurer de la conformité de ses pratiques locatives au droit applicable (loi ALUR, ELAN, etc.)</li>
            <li>Ne pas partager ses identifiants avec des tiers</li>
          </ul>
          <p className="mt-3">L&apos;utilisateur est seul responsable de l&apos;exactitude des informations qu&apos;il saisit dans la plateforme et de l&apos;utilisation qu&apos;il fait des documents générés.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 6 — Propriété intellectuelle</h2>
          <p>La plateforme Mon Parc Locatif, son code source, son design, ses contenus et ses documents types sont la propriété exclusive de Rémi DUMAS. Toute reproduction, représentation, modification ou exploitation sans autorisation écrite préalable est interdite.</p>
          <p className="mt-3">Les documents générés par l&apos;utilisateur à partir de ses propres données lui appartiennent. L&apos;éditeur se réserve le droit d&apos;utiliser des données anonymisées et agrégées à des fins d&apos;amélioration du service.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 7 — Responsabilité et limitations</h2>
          <p>Mon Parc Locatif est un outil d&apos;aide à la gestion locative. Les documents générés le sont à titre indicatif et ne constituent pas un conseil juridique. L&apos;éditeur recommande à l&apos;utilisateur de consulter un professionnel du droit pour toute situation complexe.</p>
          <p className="mt-3">L&apos;éditeur ne saurait être tenu responsable des préjudices résultant :</p>
          <ul className="list-disc pl-6 mt-3 space-y-1.5">
            <li>D&apos;une mauvaise utilisation de la plateforme ou des documents générés</li>
            <li>D&apos;une interruption temporaire du service pour maintenance</li>
            <li>D&apos;informations inexactes saisies par l&apos;utilisateur</li>
            <li>D&apos;un accès non autorisé au compte de l&apos;utilisateur dû à la négligence de ce dernier</li>
          </ul>
          <p className="mt-3">L&apos;éditeur s&apos;engage à maintenir un service disponible 99% du temps, hors opérations de maintenance planifiées.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 8 — Résiliation</h2>
          <p>L&apos;utilisateur peut résilier son abonnement à tout moment depuis son espace personnel ou en contactant l&apos;éditeur à l&apos;adresse contact@moncontratdelocation.fr. La résiliation prend effet à la fin de la période d&apos;abonnement en cours.</p>
          <p className="mt-3">En cas de résiliation, les données de l&apos;utilisateur sont conservées pendant 30 jours, puis supprimées définitivement. L&apos;utilisateur est invité à télécharger ses données avant la résiliation.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 9 — Modification des CGU</h2>
          <p>L&apos;éditeur se réserve le droit de modifier les présentes CGU à tout moment. Les utilisateurs seront informés de toute modification substantielle par email au moins 30 jours avant son entrée en vigueur. La poursuite de l&apos;utilisation du service après cette période vaut acceptation des nouvelles CGU.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">Article 10 — Loi applicable et juridiction</h2>
          <p>Les présentes CGU sont soumises au droit français. En cas de litige, une solution amiable sera recherchée en priorité. À défaut, les tribunaux compétents de Paris seront seuls compétents.</p>
          <p className="mt-3">Pour toute question relative aux présentes CGU : <strong>contact@moncontratdelocation.fr</strong></p>
        </section>
      </div>
    </div>
  )
}
